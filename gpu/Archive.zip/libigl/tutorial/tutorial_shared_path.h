#ifndef tutorial_shared_path_h_included
#define tutorial_shared_path_h_included

#ifndef TUTORIAL_SHARED_PATH
#define TUTORIAL_SHARED_PATH "../shared"
#endif

#endif
